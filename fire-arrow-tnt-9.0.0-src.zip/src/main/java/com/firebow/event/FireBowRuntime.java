package com.firebow.event;

import com.firebow.target.PlacementTarget;
import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * FireBowRuntime v9 — kiến trúc sạch theo BOOST-FPS:
 *
 * - PlacementTarget: check inventory 1 lần duy nhất, tái sử dụng slot
 * - InventoryUtil: tìm hotbar bằng Predicate
 * - InteractionUtil: đặt block sạch, không side effect
 * - InputBlocker: block input khi đang chạy
 * - Triple dedup: queue + processing + recentDone
 * - Delay nhanh: 20ms rail→cart, 10ms restore
 * - Ping compensation tự động
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private static final String BLOCKER_KEY = "firebow.placement";

    private static final long RAIL_TO_CART_BASE_MS   = 20L;
    private static final long RAIL_TO_CART_JITTER_MS = 5L;
    private static final long SLOT_RESTORE_BASE_MS   = 10L;
    private static final long SLOT_RESTORE_JITTER_MS = 3L;

    private final Queue<BlockPos> queue      = new ConcurrentLinkedQueue<>();
    private final Set<BlockPos>   processing = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<BlockPos>   recentDone = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final AtomicBoolean   busy       = new AtomicBoolean(false);
    private final TickSynchronizer tickSync  = new TickSynchronizer();

    private static final int MAX_QUEUE = 4;
    private volatile boolean enabled = true;

    private FireBowRuntime() {}

    public boolean isEnabled()           { return enabled; }
    public void    toggle()              { enabled = !enabled; }

    public void enqueue(BlockPos pos) {
        if (!enabled) return;
        // Triple dedup
        if (queue.contains(pos))      return;
        if (processing.contains(pos)) return;
        if (recentDone.contains(pos)) return;

        if (queue.size() < MAX_QUEUE) queue.add(pos);
        if (!busy.get()) processNext();
    }

    public void onClientTick(MinecraftClient client) {
        tickSync.onClientTick();
        if (!queue.isEmpty() && !busy.get()) processNext();
    }

    // ─────────────────────────────────────────────────────────────
    private void processNext() {
        if (!busy.compareAndSet(false, true)) return;
        BlockPos pos = queue.poll();
        if (pos == null) { busy.set(false); return; }

        processing.add(pos);
        InputBlocker.block(BLOCKER_KEY);

        AsyncRunner.run(() -> {
            try {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player == null || !enabled) return;
                if (!InteractionUtil.inReach(mc.player, pos)) return;

                // ── Tạo target và check inventory 1 lần ──
                // Phải có cả rail lẫn cart — nếu thiếu 1 → abort
                final PlacementTarget[] targetRef = { null };
                safeExecute(mc, () -> {
                    targetRef[0] = PlacementTarget.tryCreate(pos);
                });

                PlacementTarget target = targetRef[0];
                if (target == null) return; // thiếu rail hoặc cart

                // Đọc ping trên game thread — tránh race condition
                final long[] lag = { 0L };
                safeExecute(mc, () -> lag[0] = PingUtil.lagBonus(mc));
                long lagBonus = lag[0];

                tickSync.awaitNextTick(100L);

                // ── STEP 1: Đặt Rail ──
                boolean[] railOk  = { false };
                final int[] saved = { 0 };

                safeExecute(mc, () -> {
                    if (mc.player == null) return;
                    saved[0] = mc.player.getInventory().selectedSlot;
                    mc.player.getInventory().selectedSlot = target.railSlot.slot;
                    railOk[0] = InteractionUtil.placeBelow(mc, pos);
                });
                if (!railOk[0]) return;

                // ── STEP 2: Delay rail→cart ──
                long delay = RAIL_TO_CART_BASE_MS + lagBonus
                    + ThreadLocalRandom.current().nextLong(
                        -RAIL_TO_CART_JITTER_MS, RAIL_TO_CART_JITTER_MS + 1);
                Thread.sleep(Math.max(15L, delay));
                tickSync.awaitNextTick(100L);

                // ── STEP 3: Đặt TNT Cart — CHỈ 1 LẦN ──
                safeExecute(mc, () -> {
                    if (mc.player == null) return;

                    // Confirm rail đã spawn trên server
                    boolean hasRail =
                        mc.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                        mc.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);
                    if (!hasRail) return;

                    // Re-check cart slot (phòng hết trong lúc chờ)
                    SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                    if (cart.isMissing()) return;

                    mc.player.getInventory().selectedSlot = cart.slot;
                    InteractionUtil.placeOnTop(mc, pos);
                });

                // ── STEP 4: Restore slot ──
                long restoreDelay = SLOT_RESTORE_BASE_MS + lagBonus
                    + ThreadLocalRandom.current().nextLong(
                        -SLOT_RESTORE_JITTER_MS, SLOT_RESTORE_JITTER_MS + 1);
                Thread.sleep(Math.max(8L, restoreDelay));

                tickSync.awaitNextTick(100L);
                final int slotToRestore = saved[0];
                safeExecute(mc, () -> {
                    if (mc.player != null)
                        mc.player.getInventory().selectedSlot = slotToRestore;
                });

                // Đánh dấu done — block re-enqueue 3 giây
                recentDone.add(pos);
                AsyncRunner.runDelayed(() -> recentDone.remove(pos), 3000L);

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Exception ignored) {
            } finally {
                InputBlocker.unblock(BLOCKER_KEY);
                processing.remove(pos);
                busy.set(false);
                if (!queue.isEmpty()) processNext();
            }
        });
    }

    private void safeExecute(MinecraftClient mc, Runnable action) {
        final boolean[] done = { false };
        mc.execute(() -> {
            try { action.run(); }
            catch (Exception ignored) {}
            finally {
                synchronized (done) { done[0] = true; done.notifyAll(); }
            }
        });
        synchronized (done) {
            long deadline = System.currentTimeMillis() + 300L;
            while (!done[0]) {
                long rem = deadline - System.currentTimeMillis();
                if (rem <= 0) break;
                try { done.wait(rem); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
        }
    }
}
